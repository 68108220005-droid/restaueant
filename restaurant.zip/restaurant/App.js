import 'react-native-url-polyfill/auto';
import React, { useEffect, useState } from 'react';
import { 
  View, Text, FlatList, StyleSheet, Image, ActivityIndicator, 
  SafeAreaView, TouchableOpacity, ScrollView, Modal, TextInput, KeyboardAvoidingView, Platform, Alert
} from 'react-native';
import { createClient } from '@supabase/supabase-js';
import { Ionicons } from '@expo/vector-icons';

// 🔴 1. ตรวจสอบ URL และ ANON_KEY ของคุณตรงนี้
const supabaseUrl = 'https://dgqdoygedjpfucbchtyo.supabase.co';
const supabaseAnonKey = 'sb_publishable_vXgVvdYb43O_4u3YerEEnQ_cz7EkGRA'; // ใส่ Key จริงของคุณตรงนี้

const supabase = createClient(supabaseUrl, supabaseAnonKey);
const CATEGORIES = ['ทั้งหมด', 'อาหารจานเดียว', 'ต้ม/แกง', 'ผัด/ทอด', 'ยำ/ส้มตำ'];
const DELIVERY_FEE = 30; // ค่าจัดส่งคงที่ 30 บาท

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [authUsername, setAuthUsername] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  const [menu, setMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('ทั้งหมด');

  const [selectedFood, setSelectedFood] = useState(null);
  const [itemQty, setItemQty] = useState(1);
  const [itemNote, setItemNote] = useState('');
  const [foodReviews, setFoodReviews] = useState([]);
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);

  // === ระบบตะกร้า & การชำระเงิน ===
  const [cart, setCart] = useState([]);
  const [isCartVisible, setIsCartVisible] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('PromptPay');
  const [isOrdering, setIsOrdering] = useState(false);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.from('menu_items').select('*');
      if (error) throw error;
      setMenu(data || []);
    } catch (e) {
      console.log('Error fetch menu:', e.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async (menuId) => {
    try {
      const { data } = await supabase.from('reviews').select('*').eq('menu_id', menuId).order('created_at', { ascending: false });
      setFoodReviews(data || []);
    } catch (e) {
      console.log('Error fetch reviews:', e.message);
    }
  };

  const handleAuth = async () => {
    setAuthError('');
    if (!authUsername.trim() || !authPassword.trim()) {
      setAuthError('กรุณากรอกชื่อผู้ใช้และรหัสผ่านให้ครบ');
      return;
    }

    setAuthLoading(true);
    try {
      if (isLoginMode) {
        const { data, error } = await supabase
          .from('app_users')
          .select('*')
          .eq('username', authUsername.trim())
          .eq('password', authPassword.trim())
          .maybeSingle();

        if (error) throw error;
        if (data) {
          setCurrentUser(data);
          setCustomerName(data.username);
        } else {
          setAuthError('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
        }
      } else {
        const { data, error } = await supabase
          .from('app_users')
          .insert([{ username: authUsername.trim(), password: authPassword.trim() }])
          .select()
          .single();

        if (error) {
          if (error.code === '23505') setAuthError('ชื่อผู้ใช้นี้มีคนใช้งานแล้ว');
          else setAuthError('สมัครไม่สำเร็จ: ' + error.message);
        } else if (data) {
          setCurrentUser(data);
          setCustomerName(data.username);
        }
      }
    } catch (err) {
      setAuthError('ข้อผิดพลาด: ' + (err.message || 'ไม่สามารถเชื่อมต่อ Supabase ได้'));
    } finally {
      setAuthLoading(false);
    }
  };

  const openFoodDetail = (item) => {
    setSelectedFood(item);
    setItemQty(1);
    setItemNote('');
    fetchReviews(item.id);
  };

  const handleAddToCart = () => {
    const existing = cart.findIndex(c => c.item.id === selectedFood.id && c.note === itemNote);
    if (existing > -1) {
      let newCart = [...cart];
      newCart[existing].qty += itemQty;
      setCart(newCart);
    } else {
      setCart([...cart, { item: selectedFood, qty: itemQty, note: itemNote }]);
    }
    setSelectedFood(null);
  };

  // 🆕 ฟังก์ชันยกเลิก / ลบรายการอาหารออกจากตะกร้า
  const handleRemoveFromCart = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    if (newCart.length === 0) {
      setIsCartVisible(false); // ปิดตะกร้าอัตโนมัติเมื่อรายการหมด
    }
  };

  // 🆕 ฟังก์ชันยกเลิกรายการทั้งหมดในตะกร้า
  const handleClearCart = () => {
    setCart([]);
    setIsCartVisible(false);
  };

  const submitReview = async () => {
    if (!newReviewText.trim()) return;
    try {
      await supabase.from('reviews').insert([{ 
        menu_id: selectedFood.id, 
        username: currentUser.username, 
        rating: newReviewRating, 
        comment: newReviewText.trim() 
      }]);
      setNewReviewText('');
      fetchReviews(selectedFood.id);
    } catch (e) {
      alert('ส่งรีวิวไม่สำเร็จ: ' + e.message);
    }
  };

  const handleCheckout = async () => {
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      alert('กรุณากรอกชื่อ, เบอร์โทรศัพท์ และที่อยู่จัดส่งให้ครบถ้วน');
      return;
    }

    setIsOrdering(true);
    try {
      const subtotal = cart.reduce((sum, c) => sum + (c.item.price * c.qty), 0);
      const grandTotal = subtotal + DELIVERY_FEE;

      const orderData = {
        customer_name: customerName,
        customer_phone: customerPhone,
        customer_address: customerAddress,
        items: cart.map(c => ({ name: c.item.name, qty: c.qty, price: c.item.price, note: c.note })),
        subtotal: subtotal,
        delivery_fee: DELIVERY_FEE,
        total_price: grandTotal,
        payment_method: paymentMethod === 'PromptPay' ? 'พร้อมเพย์' : 'เก็บเงินปลายทาง',
        status: 'กำลังเตรียมอาหาร'
      };

      const { error } = await supabase.from('orders').insert([orderData]);
      if (error) throw error;

      alert('🎉 สั่งซื้อและชำระเงินเรียบร้อยแล้ว! ร้านกำลังเตรียมจัดส่งให้คุณ');
      setCart([]);
      setIsCartVisible(false);
    } catch (e) {
      alert('เกิดข้อผิดพลาดในการสั่งซื้อ: ' + e.message);
    } finally {
      setIsOrdering(false);
    }
  };

  const filteredMenu = activeCategory === 'ทั้งหมด' ? menu : menu.filter(m => m.category === activeCategory);
  const subtotal = cart.reduce((sum, c) => sum + (c.item.price * c.qty), 0);
  const grandTotal = subtotal > 0 ? subtotal + DELIVERY_FEE : 0;

  // ==========================================
  // 1. หน้า Login / Register
  // ==========================================
  if (!currentUser) {
    return (
      <SafeAreaView style={styles.authContainer}>
        <View style={styles.authBox}>
          <Ionicons name="restaurant" size={60} color="#E67E22" style={{ alignSelf: 'center', marginBottom: 15 }} />
          <Text style={styles.authTitle}>{isLoginMode ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}</Text>
          
          {authError ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{authError}</Text>
            </View>
          ) : null}

          <TextInput style={styles.input} placeholder="ชื่อผู้ใช้งาน" value={authUsername} onChangeText={setAuthUsername} autoCapitalize="none" />
          <TextInput style={styles.input} placeholder="รหัสผ่าน" value={authPassword} onChangeText={setAuthPassword} secureTextEntry />
          
          <TouchableOpacity style={styles.primaryBtn} onPress={handleAuth} disabled={authLoading}>
            {authLoading ? <ActivityIndicator color="white" /> : (
              <Text style={styles.primaryBtnText}>{isLoginMode ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity onPress={() => { setIsLoginMode(!isLoginMode); setAuthError(''); }}>
            <Text style={styles.switchAuthText}>{isLoginMode ? 'ยังไม่มีบัญชี? สมัครสมาชิกที่นี่' : 'มีบัญชีแล้ว? เข้าสู่ระบบ'}</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.bypassBtn}
            onPress={() => {
              setCurrentUser({ id: 999, username: 'ผู้ใช้งานทดลอง' });
              setCustomerName('ผู้ใช้งานทดลอง');
            }}
          >
            <Text style={styles.bypassBtnText}>⚡ กดตรงนี้เพื่อข้ามไปทดลองใช้งานทันที</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ==========================================
  // 2. หน้าจอหลักรายการอาหาร
  // ==========================================
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>ร้านอาหารไทยแซ่บอีหลี</Text>
          <Text style={{ color: 'white', fontSize: 13 }}>ยินดีต้อนรับ: {currentUser.username}</Text>
        </View>
        <TouchableOpacity onPress={() => setCurrentUser(null)}>
          <Ionicons name="log-out-outline" size={26} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.categoryContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {CATEGORIES.map((cat, i) => (
            <TouchableOpacity key={i} style={[styles.categoryBtn, activeCategory === cat && styles.categoryBtnActive]} onPress={() => setActiveCategory(cat)}>
              <Text style={[styles.categoryText, activeCategory === cat && styles.categoryTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {loading ? <ActivityIndicator size="large" color="#E67E22" style={{ flex: 1 }} /> : (
        <FlatList
          data={filteredMenu}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={{ padding: 15, paddingBottom: 100 }}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.menuCard} onPress={() => openFoodDetail(item)}>
              <Image source={{ uri: item.image_url }} style={styles.menuImage} />
              <View style={styles.menuInfo}>
                <Text style={styles.menuName}>{item.name}</Text>
                <Text style={styles.menuDesc} numberOfLines={2}>{item.description}</Text>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={styles.menuPrice}>฿{item.price}</Text>
                  <View style={styles.viewDetailBtn}><Text style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>เลือก / ดูรายละเอียด</Text></View>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      )}

      {cart.length > 0 && (
        <TouchableOpacity style={styles.floatingCart} onPress={() => setIsCartVisible(true)}>
          <View style={styles.cartBadge}><Text style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>{cart.length}</Text></View>
          <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>ดูตะกร้าสั่งซื้อ (฿{grandTotal})</Text>
          <Ionicons name="cart" size={22} color="white" />
        </TouchableOpacity>
      )}

      {/* Modal รายละเอียดอาหาร & เลือกจำนวน & รีวิว */}
      <Modal visible={!!selectedFood} animationType="slide">
        {selectedFood && (
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView>
              <Image source={{ uri: selectedFood.image_url }} style={styles.detailImage} />
              <TouchableOpacity style={styles.closeModalBtn} onPress={() => setSelectedFood(null)}>
                <Ionicons name="close-circle" size={36} color="rgba(0,0,0,0.6)" />
              </TouchableOpacity>
              
              <View style={styles.detailContent}>
                <Text style={styles.detailTitle}>{selectedFood.name}</Text>
                <Text style={styles.detailPrice}>฿{selectedFood.price}</Text>
                <Text style={styles.detailDesc}>{selectedFood.description}</Text>

                <View style={styles.sectionDivider} />

                <Text style={styles.sectionTitle}>รายละเอียดการสั่งซื้อ</Text>
                <View style={styles.qtyRow}>
                  <Text style={{ fontSize: 16, fontWeight: 'bold' }}>จำนวน</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <TouchableOpacity style={styles.qtyBtn} onPress={() => setItemQty(Math.max(1, itemQty - 1))}>
                      <Ionicons name="remove" size={20} color="white" />
                    </TouchableOpacity>
                    <Text style={styles.qtyValue}>{itemQty}</Text>
                    <TouchableOpacity style={styles.qtyBtn} onPress={() => setItemQty(itemQty + 1)}>
                      <Ionicons name="add" size={20} color="white" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <TextInput 
                  style={[styles.input, { height: 60, textAlignVertical: 'top' }]} 
                  placeholder="ระบุรายละเอียด เช่น ไม่เผ็ด, ไม่ใส่ผัก"
                  value={itemNote}
                  onChangeText={setItemNote}
                  multiline
                />

                <TouchableOpacity style={styles.addToCartBtn} onPress={handleAddToCart}>
                  <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>เพิ่มลงตะกร้า - ฿{selectedFood.price * itemQty}</Text>
                </TouchableOpacity>

                <View style={styles.sectionDivider} />

                <Text style={styles.sectionTitle}>รีวิวจากลูกค้า</Text>
                <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                  {[1,2,3,4,5].map(star => (
                    <TouchableOpacity key={star} onPress={() => setNewReviewRating(star)}>
                      <Ionicons name={star <= newReviewRating ? 'star' : 'star-outline'} size={28} color="#FFD700" />
                    </TouchableOpacity>
                  ))}
                </View>
                <View style={{ flexDirection: 'row', marginBottom: 15 }}>
                  <TextInput style={[styles.input, { flex: 1, marginRight: 10, marginBottom: 0 }]} placeholder="เขียนรีวิวอาหารจานนี้..." value={newReviewText} onChangeText={setNewReviewText} />
                  <TouchableOpacity style={styles.sendReviewBtn} onPress={submitReview}>
                    <Ionicons name="send" size={18} color="white" />
                  </TouchableOpacity>
                </View>

                {foodReviews.map(r => (
                  <View key={r.id} style={styles.reviewBox}>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                      <Text style={{ fontWeight: 'bold' }}>{r.username}</Text>
                      <View style={{ flexDirection: 'row' }}>
                        {[...Array(r.rating)].map((_, i) => <Ionicons key={i} name="star" size={12} color="#FFD700" />)}
                      </View>
                    </View>
                    <Text style={{ color: '#555', marginTop: 4 }}>{r.comment}</Text>
                  </View>
                ))}
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        )}
      </Modal>

      {/* ==========================================
      // 3. Modal ตะกร้าสินค้า + ปุ่มยกเลิกเมนู + ชำระเงิน
      // ========================================== */}
      <Modal visible={isCartVisible} animationType="slide">
        <SafeAreaView style={{ flex: 1, backgroundColor: '#F9F9F9' }}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>🛒 ตะกร้าสินค้า & ชำระเงิน</Text>
            <TouchableOpacity onPress={() => setIsCartVisible(false)}><Ionicons name="close" size={28} color="white" /></TouchableOpacity>
          </View>
          <ScrollView style={{ padding: 15 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <Text style={styles.sectionTitle}>รายการอาหารที่สั่ง</Text>
              {cart.length > 0 && (
                <TouchableOpacity onPress={handleClearCart}>
                  <Text style={{ color: '#E74C3C', fontSize: 13, fontWeight: 'bold' }}>ล้างตะกร้าทั้งหมด</Text>
                </TouchableOpacity>
              )}
            </View>

            {cart.map((c, i) => (
              <View key={i} style={styles.cartItem}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 15 }}>{c.item.name} x{c.qty}</Text>
                  {c.note ? <Text style={{ color: '#E67E22', fontSize: 12 }}>*หมายเหตุ: {c.note}</Text> : null}
                </View>
                <Text style={{ fontWeight: 'bold', color: '#27AE60', fontSize: 15, marginRight: 12 }}>฿{c.item.price * c.qty}</Text>
                
                {/* 🗑️ ปุ่มกดยกเลิก / ลบรายการอาหารจานนี้ */}
                <TouchableOpacity style={styles.cancelItemBtn} onPress={() => handleRemoveFromCart(i)}>
                  <Ionicons name="trash-outline" size={20} color="#E74C3C" />
                </TouchableOpacity>
              </View>
            ))}

            {/* ส่วนคำนวณเงินและค่าจัดส่ง */}
            <View style={styles.summaryBox}>
              <View style={styles.summaryRow}>
                <Text style={{ color: '#666' }}>ค่าอาหาร:</Text>
                <Text style={{ fontWeight: 'bold' }}>฿{subtotal}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={{ color: '#666' }}>🛵 ค่าจัดส่ง (Delivery Fee):</Text>
                <Text style={{ fontWeight: 'bold' }}>฿{DELIVERY_FEE}</Text>
              </View>
              <View style={[styles.summaryRow, { borderTopWidth: 1, borderColor: '#DDD', paddingTop: 8, marginTop: 5 }]}>
                <Text style={{ fontWeight: 'bold', fontSize: 16 }}>ยอดรวมสุทธิ:</Text>
                <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#E67E22' }}>฿{grandTotal}</Text>
              </View>
            </View>

            {/* ฟอร์มที่อยู่จัดส่ง */}
            <Text style={[styles.sectionTitle, { marginTop: 20 }]}>📍 ข้อมูลที่อยู่จัดส่ง</Text>
            <TextInput style={styles.input} placeholder="ชื่อผู้รับ *" value={customerName} onChangeText={setCustomerName} />
            <TextInput style={styles.input} placeholder="เบอร์โทรศัพท์ *" keyboardType="phone-pad" value={customerPhone} onChangeText={setCustomerPhone} />
            <TextInput style={[styles.input, { height: 70, textAlignVertical: 'top' }]} placeholder="ที่อยู่จัดส่งโดยละเอียด *" value={customerAddress} onChangeText={setCustomerAddress} multiline />

            {/* เลือกการชำระเงิน */}
            <Text style={styles.sectionTitle}>💳 เลือกวิธีชำระเงิน</Text>
            <View style={{ flexDirection: 'row', marginBottom: 15 }}>
              <TouchableOpacity style={[styles.payOption, paymentMethod === 'PromptPay' && styles.payOptionActive]} onPress={() => setPaymentMethod('PromptPay')}>
                <Ionicons name="qr-code-outline" size={20} color={paymentMethod === 'PromptPay' ? 'white' : '#555'} />
                <Text style={{ color: paymentMethod === 'PromptPay' ? 'white' : '#555', fontWeight: 'bold', marginLeft: 5 }}>พร้อมเพย์ (PromptPay)</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.payOption, paymentMethod === 'COD' && styles.payOptionActive]} onPress={() => setPaymentMethod('COD')}>
                <Ionicons name="cash-outline" size={20} color={paymentMethod === 'COD' ? 'white' : '#555'} />
                <Text style={{ color: paymentMethod === 'COD' ? 'white' : '#555', fontWeight: 'bold', marginLeft: 5 }}>เก็บเงินปลายทาง</Text>
              </TouchableOpacity>
            </View>

            {/* แสดง QR Code พร้อมเพย์ */}
            {paymentMethod === 'PromptPay' && (
              <View style={styles.qrContainer}>
                <Text style={{ fontSize: 13, color: '#666', marginBottom: 8 }}>สแกน QR Code นี้เพื่อชำระเงิน</Text>
                <Image source={{ uri: `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=PROMPTPAY_${grandTotal}` }} style={{ width: 160, height: 160 }} />
                <Text style={{ marginTop: 8, fontWeight: 'bold', color: '#E67E22', fontSize: 16 }}>ยอดโอน: ฿{grandTotal}</Text>
              </View>
            )}

            {/* ปุ่มกดสั่งซื้อ / ชำระเงิน */}
            <TouchableOpacity style={styles.checkoutBtn} onPress={handleCheckout} disabled={isOrdering}>
              {isOrdering ? <ActivityIndicator color="white" /> : (
                <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 18 }}>ยืนยันสั่งซื้อและชำระเงิน (฿{grandTotal})</Text>
              )}
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F2F5' },
  header: { backgroundColor: '#E67E22', padding: 18, paddingTop: Platform.OS === 'android' ? 35 : 18, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: 'white' },
  authContainer: { flex: 1, justifyContent: 'center', backgroundColor: '#F0F2F5', padding: 20 },
  authBox: { backgroundColor: 'white', padding: 25, borderRadius: 16, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  authTitle: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 15, color: '#333' },
  errorBox: { backgroundColor: '#FFEBEE', padding: 10, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#FFCDD2' },
  errorText: { color: '#D32F2F', fontSize: 13, textAlign: 'center', fontWeight: 'bold' },
  input: { backgroundColor: '#F8F9FA', borderWidth: 1, borderColor: '#E9ECEF', padding: 12, borderRadius: 10, marginBottom: 12, fontSize: 15 },
  primaryBtn: { backgroundColor: '#E67E22', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 5 },
  primaryBtnText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  switchAuthText: { textAlign: 'center', marginTop: 15, color: '#E67E22', fontWeight: 'bold', fontSize: 13 },
  bypassBtn: { marginTop: 18, paddingTop: 12, borderTopWidth: 1, borderColor: '#EEE', alignItems: 'center' },
  bypassBtnText: { color: '#7f8c8d', fontSize: 12, fontWeight: 'bold' },
  categoryContainer: { backgroundColor: 'white', paddingVertical: 10, paddingHorizontal: 10, elevation: 2 },
  categoryBtn: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F0F0F0', marginRight: 8 },
  categoryBtnActive: { backgroundColor: '#E67E22' },
  categoryText: { color: '#666', fontWeight: 'bold', fontSize: 13 },
  categoryTextActive: { color: 'white' },
  menuCard: { backgroundColor: 'white', borderRadius: 12, marginBottom: 12, flexDirection: 'row', overflow: 'hidden', elevation: 2 },
  menuImage: { width: 100, height: 100, backgroundColor: '#EEE' },
  menuInfo: { flex: 1, padding: 10, justifyContent: 'space-between' },
  menuName: { fontSize: 16, fontWeight: 'bold', color: '#222' },
  menuDesc: { fontSize: 12, color: '#777' },
  menuPrice: { fontSize: 16, fontWeight: 'bold', color: '#E67E22' },
  viewDetailBtn: { backgroundColor: '#27AE60', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  detailImage: { width: '100%', height: 220 },
  closeModalBtn: { position: 'absolute', top: 35, right: 15 },
  detailContent: { padding: 18 },
  detailTitle: { fontSize: 22, fontWeight: 'bold', color: '#222' },
  detailPrice: { fontSize: 20, fontWeight: 'bold', color: '#E67E22', marginVertical: 4 },
  detailDesc: { fontSize: 14, color: '#666' },
  sectionDivider: { height: 1, backgroundColor: '#EEE', marginVertical: 15 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 10, color: '#333' },
  qtyRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  qtyBtn: { backgroundColor: '#E67E22', width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  qtyValue: { fontSize: 18, fontWeight: 'bold', marginHorizontal: 15 },
  addToCartBtn: { backgroundColor: '#27AE60', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 5 },
  sendReviewBtn: { backgroundColor: '#E67E22', justifyContent: 'center', paddingHorizontal: 14, borderRadius: 10 },
  reviewBox: { backgroundColor: '#F8F9FA', padding: 10, borderRadius: 8, marginTop: 8, borderWidth: 1, borderColor: '#EEE' },
  floatingCart: { position: 'absolute', bottom: 25, left: 15, right: 15, backgroundColor: '#222', borderRadius: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, elevation: 5 },
  cartBadge: { position: 'absolute', top: -5, left: -5, backgroundColor: '#E74C3C', width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center', zIndex: 10 },
  cartItem: { backgroundColor: 'white', padding: 12, borderRadius: 10, marginBottom: 8, flexDirection: 'row', alignItems: 'center', elevation: 1 },
  cancelItemBtn: { padding: 6, backgroundColor: '#FFEBEE', borderRadius: 8 },
  summaryBox: { backgroundColor: 'white', padding: 12, borderRadius: 10, marginVertical: 10 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 3 },
  payOption: { flex: 1, flexDirection: 'row', padding: 12, borderWidth: 1, borderColor: '#DDD', borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 8, backgroundColor: 'white' },
  payOptionActive: { backgroundColor: '#E67E22', borderColor: '#E67E22' },
  qrContainer: { alignItems: 'center', backgroundColor: 'white', padding: 15, borderRadius: 10, marginBottom: 15, borderWidth: 1, borderColor: '#EEE' },
  checkoutBtn: { backgroundColor: '#27AE60', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10, marginBottom: 40 }
});